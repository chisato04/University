<?php 

    $alert = NULL;
    $_SESSION['refresh'] = 0;

    if($alert){
        while($_SESSION['refresh'] <= 2);{
            $_SESSION['refresh'] = $_SESSION['refresh'] + 1;
        }
    }

    if($_SESSION['refresh'] > 2){
        $alert = false;
        $_SESSION['refresh'] = 0;
    }

?>