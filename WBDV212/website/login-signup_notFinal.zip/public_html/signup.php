<?php
    session_start();
    $_SESSION['refresh'] += 1; //yes, the submission of data to the db does count as a page refresh, which the runs this incrementation
    require_once 'connection.php';
    require 'check_dupe.php';


    if(isset($_POST["signup"])){

        if(!($exists)){
            $email = $_POST["email"];
            $password = $_POST["password"];

            $query = "INSERT INTO user_accounts(email, password) VALUES('$email', '$password');";
            
            mysqli_query($connect, $query);

            $find = "SELECT user_id from user_accounts WHERE email='$email' and password='$password';";
            $grab = mysqli_query($connect, $find);
            $result = mysqli_fetch_array($grab);
            
            $new_user_id = $result["user_id"];
            
            $query2 = "INSERT INTO user_info(user_id) VALUES($new_user_id)";
            
            mysqli_query($connect, $query2);

            $created = true; //this will  setup a true condition for echoing out "Account created" in styles


        }
    }

    if($created === true || $created === NULL){
        $alert = false;
        // if($_SESSION['refresh'] > 1){ //instantly switches to login, find a way to change this
        //     $_SESSION['refresh'] = 0;
        //     $created = false; 
        //     echo "<script type ='text/javascript'> window.location.href = 'login.php'; </script>";
        // }
    }else{
        $alert = true;
    }
    
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Sign-up | </title>
        <link rel=stylesheet type=text/css href=styles/signup-login.css />
        <?php include "google-fonts.php" ?>
        <style>
            <?php include "account_creation_alert.php" ?>
        </style>
    </head>
    <body>
        <form action='' method=post id='sign-up' autocomplete=on>
            <h1>Sign-up</h1> <?php echo $_SESSION['refresh'] ?>
            <!--<fieldset>-->
                <label>
                    <input type=email name=email placeholder=Email pattern='^[\\w\\-]+(\\.[\\w\\-]+)*@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$
	                ^[\w-]+(\.[\w-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)*?\.[a-z]{2,6}|(\d{1,3}\.){3}\d{1,3})(:\d{4})?$ 
	                ^([\w\.*\-*]+@([\w]\.*\-*)+[a-zA-Z]{2,9}(\s*;\s*[\w\.*\-*]+@([\w]\.*\-*)+[a-zA-Z]{2,9})*)$' required=required title="Please enter a valid email" />
                </label>                                                    
                <label>
                    <input type=password name=password placeholder="Password" required=required />
                </label>
                <label>
                    <input type=checkbox name=agreement value="yes" required=required id=checkbox /> <span id="agreement">I agree to the <a href=''>terms and conditions</a>.</span>
                </label>
                    <input type=submit name=signup value=Signup />

                <p id=switch_to>Already have an account? <a href=login.php>Sign-in</a></p>
            <!--</fieldset>-->
        </form>
    </body>
</html>
