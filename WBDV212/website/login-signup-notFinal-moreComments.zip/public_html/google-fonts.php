        <!--FONT: Roboto-->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
            <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
        <!--FONT: Roboto-->
        <!--FONT: Raleway-->
            <link rel="preconnect" href="https://fonts.googleapis.com" />
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
            <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@600&family=Roboto&display=swap" rel="stylesheet" />
        <!--FONT: Raleway-->
        <!--FONT: Lexend-->
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@500&display=swap" rel="stylesheet">
        <!--FONT: Lexend-->
        <!--FONT: Be Vietnam Pro-->
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@500&display=swap" rel="stylesheet">
        <!--FONT: Be Vietnam Pro-->



<!--all googlefonts link are stored here kasi dadagdag sa clutter pag nilagay sa kada page, gumamit nalng ng include (php keyword) para shorthand form na kasama yung mga code na to sa mga page-->