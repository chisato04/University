<!DOCTYPE html>

<html>

    <head>
        <title></title>
        <link rel='stylesheet' type='text/css' href='style.css' />
        <!--FONTS-->

    </head>

    <body>

        <header>
            <img src='' id='logo' />
            <nav>
            </nav>

            <a href="signup.php" alt=>Click me</a>
        </header>

    </body>

</html>